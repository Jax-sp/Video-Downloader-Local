★ JAXMEDIA DOWNLOADER - PORTABLE EDITION ★
==========================================

¡Gracias por descargar JaxMedia Downloader!

INSTRUCCIONES DE INSTALACIÓN (Solo la primera vez):
1. Haz doble clic en el archivo "installer.bat".
   - Esto configurará el entorno y descargará lo necesario.
   - Espera a que termine y se cierre.

CÓMO USAR:
1. Después de instalar, verás un nuevo archivo llamado "LAUNCHER.bat".
2. Haz doble clic en "LAUNCHER.bat" siempre que quieras usar la app.
3. Se abrirá una ventana negra (el servidor) y tu navegador automáticamente.
4. ¡Pega el link que quieras de youtube y descarga!

NOTA:
Los archivos descargados se guardarán en tu carpeta de "Descargas" del navegador.

Es necesario tener python y FFMPeg instalados

Developed by Jax | 2026